class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        if len(word) >= self.lineWidth:
            start = (len(word) - self.lineWidth) // 2
            end = start + self.lineWidth
            centeredWord = word[start:end]
        else:
            padding = (self.lineWidth - len(word)) // 2
            centeredWord = ' ' * padding + word + ' ' * padding

        return centeredWord

    def spreadWords(self, word1, word2):
        return word1 + ' ' * (self.lineWidth - len(word1) - len(word2)) + word2




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_centeringEmtpyString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("")
    self.assertEqual(shouldBeCentered, "          ")

  def test_centeringContentString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("fooo")
    self.assertEqual(shouldBeCentered, "   fooo   ")

  def test_longerWordTakesTheMiddle(self):
    formatter = TextFormatter()
    formatter.setLineWidth(4)
    shouldBeCut = formatter.centerWord("looooong")
    self.assertEqual(shouldBeCut, "oooo")


  def test_spreadingEmptyStrings(self):
    formatter = TextFormatter()
    formatter.setLineWidth(2)
    shouldBeTwoBlanks = formatter.spreadWords("", "")
    self.assertEqual(shouldBeTwoBlanks, "  ")


if __name__ == "__main__":
  unittest.main()
