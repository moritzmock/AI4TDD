class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        if len(word) >= self.lineWidth:
            start = (len(word) - self.lineWidth) // 2
            end = start + self.lineWidth
            centeredWord = word[start:end]
        else:
            padding = (self.lineWidth - len(word)) // 2
            centeredWord = ' ' * padding + word + ' ' * padding

        return centeredWord

    def spreadWords(self, word1, word2):
        if self.lineWidth == 0:
            return ""
        
        availableWidth = self.lineWidth - len(word1) - len(word2)
        if availableWidth >= 0:
            return word1 + ' ' * availableWidth + word2
        else:
            return word1[:self.lineWidth] + word2[:self.lineWidth - len(word1)]

    # New method added to fulfill the failing test
    def spreadWorks(self, word1, word2):
        return self.spreadWords(word1, word2)






import unittest


class TestTextFormatter(unittest.TestCase):

  def test_centeringEmtpyString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("")
    self.assertEqual(shouldBeCentered, "          ")

  def test_centeringContentString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("fooo")
    self.assertEqual(shouldBeCentered, "   fooo   ")

  def test_longerWordTakesTheMiddle(self):
    formatter = TextFormatter()
    formatter.setLineWidth(4)
    shouldBeCut = formatter.centerWord("looooong")
    self.assertEqual(shouldBeCut, "oooo")

  def test_centeringToEmptyLine(self):
    formatter = TextFormatter()
    formatter.setLineWidth(0)
    shouldBeEmpty = formatter.centerWord("anything")
    self.assertEqual(shouldBeEmpty, "")


  def test_spreadingEmptyStrings(self):
    formatter = TextFormatter()
    formatter.setLineWidth(2)
    shouldBeTwoBlanks = formatter.spreadWords("", "")
    self.assertEqual(shouldBeTwoBlanks, "  ")

  def test_spreadingIntoZeroLenghtLine(self):
    formatter = TextFormatter()
    formatter.setLineWidth(0)
    shouldBeEmpty = formatter.spreadWords("ab", "cdef")
    self.assertEqual(shouldBeEmpty, "")

  def test_spreadingTwoTerms(self):
    formatter = TextFormatter()
    formatter.setLineWidth(8)
    shouldBeOK = formatter.spreadWords("ok", "beep")
    self.assertEqual(shouldBeOK, "ok  beep")


if __name__ == "__main__":
  unittest.main()
