class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        if len(word) >= self.lineWidth:
            return word

        padding = (self.lineWidth - len(word)) // 2
        centeredWord = ' ' * padding + word + ' ' * padding

        return centeredWord



class TestFormatter(TextFormatter):  # Add the TestFormatter class that inherits from TextFormatter
    pass






import unittest


class TestTextFormatter(unittest.TestCase):

  def test_centeringEmtpyString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("")
    self.assertEqual(shouldBeCentered, "          ")

  def test_centeringContentString(self):
    formatter = TestFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("fooo")
    self.assertEqual(shoudlBeCentered, "   fooo   ")


if __name__ == "__main__":
  unittest.main()
