class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        if len(word) >= self.lineWidth:
            return word

        padding = (self.lineWidth - len(word)) // 2
        centeredWord = ' ' * padding + word + ' ' * padding

        if len(centeredWord) < self.lineWidth:
            centeredWord = centeredWord[:-1]
        
        return centeredWord




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_centeringEmtpyString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("")
    self.assertEqual(shouldBeCentered, "          ")

  def test_centeringContentString(self):
    formatter = TextFormatter()
    formatter.setLineWidth(10)
    shouldBeCentered = formatter.centerWord("fooo")
    self.assertEqual(shouldBeCentered, "   fooo   ")

  def test_longerWordTakesTheMiddle(self):
    formatter = TextFormatter()
    formatter.setLineWidth(4)
    shouldBeCut = formatter.centerWord("looooong")
    self.assertEqual(shouldBeCut, "oooo")


if __name__ == "__main__":
  unittest.main()
