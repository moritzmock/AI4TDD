class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def center_text(self, word):
        padding = (self.line_width - len(word)) // 2
        if (self.line_width - len(word)) % 2 == 1:
            centered_word = " " * padding + word + " " * (padding + 1)
        else:
            centered_word = " " * padding + word + " " * padding
        return centered_word

    def spread_words(self, words):
        word_count = len(words)
        spacing = self.line_width // (word_count - 1) if word_count > 1 else 0
        spread_words = " " * spacing
        spread_words = spread_words.join(words)
        return spread_words




import unittest


class TestTextFormatter(unittest.TestCase):
    def test_word_centering(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.center_text("word"), "   word   ")

    def test_hello_centering(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.center_text("hello"), "  hello   ")
    
    def test_spread_two_words(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.spread_words(["foo", "bar"]), "foo    bar")

if __name__ == "__main__":
    unittest.main()