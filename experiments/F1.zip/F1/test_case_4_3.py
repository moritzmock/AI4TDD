def spread_words(self, words):
    spread_words = "    ".join(words)
    return spread_words




import unittest


class TestTextFormatter(unittest.TestCase):
    def test_word_centering(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.center_text("word"), "   word   ")

    def test_hello_centering(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.center_text("hello"), "  hello   ")
    
    def test_spread_two_words(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.spread_words(["foo", "bar"]), "foo    bar")

if __name__ == "__main__":
    unittest.main()