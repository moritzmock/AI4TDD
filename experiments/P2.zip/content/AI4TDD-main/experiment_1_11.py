import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    # Test if setLineWidth returns lines of the correct length
    self.assertEqual(setLineWidth(6), "------")
    self.assertEqual(setLineWidth(7), "-------")
    self.assertEqual(setLineWidth(10), "----------")


if __name__ == "__main__":
  unittest.main()
