import unittest


class TestTextFormatter(unittest.TestCase):
    def setLineWidth(self, length):
        return '-' * length

    def centerString(self, string):
        def createPadding(length):
            padding = '|'
            for i in range(length):
                padding += '-'
            padding += '|'
            return padding

        length = len(string)
        if length % 2 == 0:
            padding = createPadding((length // 2) - 1).ljust(length - 1, ' ')
        else:
            padding = createPadding(length // 2) + ' '
        return padding + string + padding

    def test_setLineWidth(self):
        # Test if setLineWidth returns lines of the correct given length
        self.assertEqual(self.setLineWidth(6), "------")
        self.assertEqual(self.setLineWidth(7), "-------")
        self.assertEqual(self.setLineWidth(10), "----------")

    def test_centerString(self):
        # Test if a word was correctly centered
        self.assertEqual(self.centerString("Text1"), "|Text1|")
        self.assertEqual(self.centerString("Text"), "|Text|")
        self.assertEqual(self.centerString("Tex"), "|Tex |")


if __name__ == "__main__":
    unittest.main()




class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    # Test if setLineWidth returns lines of the correct given length
    self.assertEqual(setLineWidth(6), "------")
    self.assertEqual(setLineWidth(7), "-------")
    self.assertEqual(setLineWidth(10), "----------")

  def test_centerString(self):
    # Test if a word was correctly centered
    self.assertEqual(centerString("Text1"), " Text1 ")
    self.assertEqual(centerString("Text"), " Text ")
    self.assertEqual(centerString("Tex"), "  Tex  ")

if __name__ == "__main__":
  unittest.main()
