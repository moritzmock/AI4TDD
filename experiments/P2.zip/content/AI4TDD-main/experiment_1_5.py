import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    self.assertEqual(setLineWidth(6), "string")


if __name__ == "__main__":
  unittest.main()
