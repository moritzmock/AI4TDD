import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    self.assertEqual(setLineWidth(6), "string")
    self.assertEqual(setLineWidth(7), "string1")
    self.assertEqual(setLineWidth(10), "string1234")


if __name__ == "__main__":
  unittest.main()
