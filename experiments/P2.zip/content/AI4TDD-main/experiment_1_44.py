import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    # Test if setLineWidth returns lines of the correct given length
    self.assertEqual(setLineWidth(6), "------")
    self.assertEqual(setLineWidth(7), "-------")
    self.assertEqual(setLineWidth(10), "----------")

  def test_centerString(self):
    # Test if a given word was correctly centered by using centerString providing the expected output length
    self.assertEqual(centerString("Text1", 7), " Text1 ")
    self.assertEqual(centerString("Text", 6), " Text ")
    self.assertEqual(centerString("Tex", 7), "  Tex  ")

  def test_wordSpread(self):
    # Test if the function spreads two words and returns the line with the words spread to the given length
    self.assertEqual(wordSpread("Word1", "Word2", 20), "Word1          Word2")
    self.assertEqual(wordSpread("Word1", "Word2", 19), "Word1         Word2")
    self.assertEqual(wordSpread("Word1", "Word", 17), "Word1        Word")

if __name__ == "__main__":
  unittest.main()
