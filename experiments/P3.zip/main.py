import unittest

class InvalidLineWidthException(Exception):
    """Invalid Line Width"""

class CenteringNotPossibleError(Exception):
    """Centering is not possible"""

class SpreadNotPossibleError(Exception):
    """Spread is not possible"""

class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, line_width):
        if line_width <= 0:
            raise InvalidLineWidthException

        self.line_width = line_width

    def centerWord(self, word):
        remaining = self.line_width - len(word)

        if remaining <= 1:
            raise CenteringNotPossibleError

        if remaining % 2 == 0:
            left = "".join([' '] * (remaining // 2))
            right = "".join([' '] * (remaining // 2))
        else:
            left = "".join([' '] * (remaining // 2 + 1))
            right = "".join([' '] * (remaining // 2))

        return left + word + right
    
    def spreadWords(self, left, right):
        remaining = self.line_width - len(left) - len(right)

        if remaining < 1:
            raise SpreadNotPossibleError
        
        middle = "".join([' '] * remaining)

        return left + middle + right

class Test(unittest.TestCase):
    def test_set_line_width(self):
        text_formatter = TextFormatter()
        
        text_formatter.setLineWidth(10)

        self.assertEqual(text_formatter.line_width, 10)

    def test_set_line_width_invalid(self):
        text_formatter = TextFormatter()
        
        with self.assertRaises(InvalidLineWidthException):
            text_formatter.setLineWidth(0)


    def test_center_word(self):
        width = 11
        text_formatter = TextFormatter()
        
        text_formatter.setLineWidth(width)

        result = text_formatter.centerWord("apple")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "   apple   ")

    def test_center_word_empty_word(self):
        width = 5
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.centerWord("")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "     ")

    def test_center_word_odd(self):
        width = 9
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.centerWord("appl")

        self.assertEqual(result, "   appl  ")

    def test_center_word_0(self):
        width = 4
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        with self.assertRaises(CenteringNotPossibleError):
            result = text_formatter.centerWord("apple")


    def test_spread_words(self):
        width = 15
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.spreadWords("apple", "pear")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "apple      pear")

    def test_spread_words_odd(self):
        width = 14
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.spreadWords("apple", "pear")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "apple     pear")

    def test_spread_words_not_possible(self):
        width = 9
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        with self.assertRaises(SpreadNotPossibleError):
            text_formatter.spreadWords("apple", "pear")

    def test_spread_words_empty_words(self):
        width = 5
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.spreadWords("", "")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "     ")

    def test_spread_words_empty_word(self):
        width = 5
        text_formatter = TextFormatter()

        text_formatter.setLineWidth(width)

        result = text_formatter.spreadWords("", "abc")

        self.assertEqual(len(result), width)
        self.assertEqual(result, "  abc")