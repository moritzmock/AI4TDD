class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2

        # Add one extra space if the word length is odd
        if word_len % 2 != 0:
            spaces_to_add += 1

        return " " * spaces_to_add + word + " " * spaces_to_add

    def equalSpread(self, word1, word2):
        word_len1 = len(word1)
        word_len2 = len(word2)

        # Calculate the number of empty spaces between the words
        total_spaces = self.line_width - word_len1 - word_len2
        spaces_between = total_spaces // (len(word1) + 1)

        # Calculate the remaining spaces for even spread
        remaining_spaces = total_spaces % (len(word1) + 1)

        result = ""

        # Add the first word to the result with the required spaces
        result += word1 + " " * spaces_between

        # Add the second word to the result with the remaining spaces
        if remaining_spaces > 0:
            result += " " * (remaining_spaces // 2)

        result += word2

        if remaining_spaces > 0:
            result += " " * (remaining_spaces // 2)

        # Add additional space if the total number of spaces is odd
        if total_spaces % 2 != 0:
            result += " "

        # Add the remaining spaces between the words
        result += " " * spaces_between + word2

        return result




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
