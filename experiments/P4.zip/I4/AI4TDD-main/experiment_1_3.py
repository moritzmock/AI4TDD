class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    textFormatter = TextFormatter(10)
    
    pass


if __name__ == "__main__":
  unittest.main()
