class TextFormatter:
    def __init__(self, width):
        self.width = width

    def centerWord(self, word):
        wordLength = len(word)
        spaces = self.width - wordLength
        leftSpaces = spaces // 2
        rightSpaces = spaces - leftSpaces

        formattedWord = " " * leftSpaces + word + " " * rightSpaces
        return formattedWord




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
