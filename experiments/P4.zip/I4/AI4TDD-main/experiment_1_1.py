class TextFormatter:
    @staticmethod
    def setLineWidth(line_width):
        return line_width




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_setLineWidth(self):
    self.assertEqual(5, TextFormatter.setLineWidth(5))
    pass


if __name__ == "__main__":
  unittest.main()
