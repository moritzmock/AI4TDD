class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2
        left_spaces = spaces_to_add
        right_spaces = spaces_to_add

        if self.line_width % 2 == 0:
            right_spaces += 1

        return " " * left_spaces + word + " " * right_spaces




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
