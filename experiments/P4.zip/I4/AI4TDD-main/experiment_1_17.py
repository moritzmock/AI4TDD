class TextFormatter:
  def __init__(self, line_length):
    self.line_length = line_length

  def centerWord(self, word):
    if len(word) >= self.line_length:
      return word

    spaces = self.line_length - len(word)
    left_spaces = spaces // 2
    right_spaces = spaces - left_spaces

    return " " * left_spaces + word + " " * right_spaces




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
