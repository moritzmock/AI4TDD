class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2

        # Add one extra space if the word length is odd
        if word_len % 2 != 0:
            spaces_to_add += 1

        return " " * spaces_to_add + word + " " * spaces_to_add

    def equalSpread(self, word1, word2):
        word1_len = len(word1)
        word2_len = len(word2)
        total_len = word1_len + word2_len + 1
        spaces_to_add = self.line_width - total_len

        # Calculate the number of spaces to add between the two words
        spaces_between = spaces_to_add // 2
        spread = " " * spaces_between + word1 + " " + word2 + " " * spaces_between

        return spread




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
