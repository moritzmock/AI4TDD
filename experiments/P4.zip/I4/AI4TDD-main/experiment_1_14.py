class TextFormatter:
    def __init__(self, max_width):
        self.max_width = max_width
    
    def centerWord(self, word):
        padding = (self.max_width - len(word)) // 2
        return " " * padding + word + " " * padding




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
