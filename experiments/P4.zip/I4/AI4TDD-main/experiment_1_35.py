class TextFormatter:
    def __init__(self, width):
        self.width = width

    def centerWord(self, word):
        spaces = self.width - len(word)
        left_spaces = spaces // 2
        right_spaces = spaces - left_spaces
        return " " * left_spaces + word + " " * right_spaces

    def equalSpread(self, word1, word2):
        total_spaces = self.width - len(word1) - len(word2)
        spaces_between = total_spaces // 2
        return " " * spaces_between + word1 + " " * spaces_between + word2





import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
