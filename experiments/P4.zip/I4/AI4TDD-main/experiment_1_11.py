class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        space = " " * ((self.line_width - len(word)) // 2)
        if len(word) % 2 == 0:
            return space + word + space
        else:
            return space + word + " " + space

    def equalSpread(self, word1, word2):
        space = " " * ((self.line_width - len(word1) - len(word2)) // 2)
        if len(word1) + len(word2) % 2 == 0:
            return space + word1 + " " + word2 + space
        else:
            return space + word1 + " " + word2 + " " + space






import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))
  
  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))
    
  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))


  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
