class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        space_count = (self.line_width - len(word)) // 2
        space = ""
        for _ in range(space_count):
            space += " "
        return space + word + space

    def equalSpread(self, word1, word2):
        space_count = (self.line_width - len(word1) - len(word2)) // 2
        space = ""
        for _ in range(space_count):
            space += " "
        return space + word1 + space + word2 + space

    def unevenSpread(self, word1, word2):
        space1_count = (self.line_width - len(word1)) // 2
        space1 = ""
        for _ in range(space1_count):
            space1 += " "

        space2_count = (self.line_width - len(word2)) // 2
        space2 = ""
        for _ in range(space2_count):
            space2 += " "

        return space1 + word1 + space1 + space2 + word2 + space2



import unittest


class TestTextFormatter(unittest.TestCase):

    def test_WordCenterEven(self):
        textFormatter = TextFormatter(10)
        self.assertEqual("   passa   ", textFormatter.centerWord("passa"))
      
    def test_WordCenterOdd(self):
        textFormatter = TextFormatter(9)
        self.assertEqual("  passa   ", textFormatter.centerWord("passa"))
        
    def test_TwoWordSpreadEven(self):
        textFormatter = TextFormatter(10)
        self.assertEqual("  eu  ou  ", textFormatter.equalSpread("eu", "ou"))
    
    def test_TwoWordSpreadOdd(self):
        textFormatter = TextFormatter(11)
        self.assertEqual("  eu   ou  ", textFormatter.unevenSpread("eu", "ou"))

if __name__ == "__main__":
    unittest.main()
