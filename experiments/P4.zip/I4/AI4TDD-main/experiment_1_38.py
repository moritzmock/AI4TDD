class TextFormatter:
    def __init__(self, width):
        self.width = width

    def centerWord(self, word):
        if len(word) >= self.width:
            return word
        else:
            padding = (self.width - len(word)) // 2
            return " " * padding + word + " " * (self.width - len(word) - padding)
        
    def equalSpread(self, word1, word2):
        if len(word1) + len(word2) >= self.width:
            return word1 + word2
        else:
            padding = self.width - len(word1) - len(word2)
            return word1 + " " * (padding // 2) + word2 + " " * (padding - (padding // 2))




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
