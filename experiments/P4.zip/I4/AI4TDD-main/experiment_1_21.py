class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2
        spaces_before = spaces_to_add
        spaces_after = spaces_to_add

        if word_len % 2 != 0:
            spaces_after += 1

        return " " * spaces_before + word + " " * spaces_after





import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
