class TextFormatter:
    def __init__(self, total_width):
        self.total_width = total_width

    def centerWord(self, word):
        # Calculate the number of spaces needed on each side of the word
        spaces = self.total_width - len(word)
        left_spaces = spaces // 2
        right_spaces = spaces - left_spaces

        # Construct the centered word with the appropriate number of spaces
        centered_word = " " * left_spaces + word + " " * right_spaces

        return centered_word

    def equalSpread(self, word1, word2):
        # Calculate the number of spaces between the two words
        spaces = self.total_width - len(word1) - len(word2)
        left_spaces = spaces // 2
        right_spaces = spaces - left_spaces

        # Construct the spread words with the appropriate number of spaces
        spread_words = " " * left_spaces + word1 + " " * right_spaces + word2

        return spread_words




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
