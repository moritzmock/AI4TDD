class TextFormatter:
    def __init__(self, width):
        self.width = width

    def centerWord(self, word):
        padding = (self.width - len(word)) // 2
        centered_word = " " * padding + word + " " * padding
        return centered_word




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
