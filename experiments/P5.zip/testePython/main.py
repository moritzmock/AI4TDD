class TextFormatter:
    line = ""

    def setLineWidth(self, lineLenght):
        for x in range(lineLenght):
            self.line += " "

    def wordCenter(self, word):
        return word.center(len(self.line))

    def wordSpread(self, firstWord, secondWord):
        firstWordLenght = len(firstWord)
        secondWordLenght = len(secondWord)
        self.line = self.line[0:len(self.line) - secondWordLenght]
        self.line = self.line[firstWordLenght: len(self.line)]
        self.line = firstWord + self.line + secondWord
        return self.line


import unittest

class TestStringMethods(unittest.TestCase):

    def test_lineWidth(self):
        textFormatter = TextFormatter()
        textFormatter.setLineWidth(8)
        self.assertEqual(8, len(textFormatter.line))

    def test_wordCenter(self):
        textFormatter = TextFormatter()
        textFormatter.setLineWidth(8)
        self.assertEqual("  para  ", textFormatter.wordCenter("para"))

    def test_wordSpread(self):
        textFormatter = TextFormatter()
        textFormatter.setLineWidth(8)
        self.assertEqual("a      b", textFormatter.wordSpread("a", "b"))

if __name__ == '__main__':
    unittest.main()


